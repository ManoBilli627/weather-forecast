package com.marwaeltayeb.weatherforecast.location

interface LocationCallback {
    fun onLocationResult()
}
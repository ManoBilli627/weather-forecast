package com.marwaeltayeb.weatherforecast.utils

interface OnNetworkListener {
    fun onNetworkConnected()
    fun onNetworkDisconnected()
}
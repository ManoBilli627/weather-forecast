package com.marwaeltayeb.weatherforecast.theme

interface ColorDialogCallback {
    fun onChosen(chosenColor: String)
}